<?php
namespace OCA\SecSignID\Exceptions;

use Exception;

class InvalidInputException extends Exception{}