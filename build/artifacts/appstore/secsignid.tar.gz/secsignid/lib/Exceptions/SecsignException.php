<?php
namespace OCA\SecSignID\Exceptions;

class SecsignException extends \Exception{}