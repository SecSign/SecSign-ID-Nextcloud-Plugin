<?php
/**
 * @author SecSign Technologies Inc.
 * @copyright 2019 SecSign Technologies Inc.
 */
$app = new OCA\SecSignID\AppInfo\Application();