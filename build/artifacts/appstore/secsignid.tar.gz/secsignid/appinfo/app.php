<?php

$app = new OCA\SecSignID\AppInfo\Application();