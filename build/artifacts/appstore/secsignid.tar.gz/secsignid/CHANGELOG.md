## [Unreleased]
### Added
- Onboarding for users
- Choose a specific SecSign ID server to query

## 0.1.1 - 2019-02-28
### Added
- Deactivation of SecSign 2FA via command line
- Admins can now always edit their personal SecSign 2FA settings

## 0.1.0 - 2019-02-26
### Added
- Simple integration of SecSign ID 2FA
- User management
