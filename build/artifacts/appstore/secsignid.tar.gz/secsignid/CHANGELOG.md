## [Unreleased]
### Added
- Onboarding for users
- Choose a specific SecSign ID server to query

## 0.1.3 - 2019-03-18
### Added
- Fixed an SQL error that was preventing users from installing correctly
- Checks for enforced two-factor authentication

## 0.1.2 - 2019-03-11
### Added
- MySQL / MariaDB support

## 0.1.1 - 2019-02-28
### Added
- Deactivation of SecSign 2FA via command line
- Admins can now always edit their personal SecSign 2FA settings

## 0.1.0 - 2019-02-26
### Added
- Simple integration of SecSign ID 2FA
- User management
