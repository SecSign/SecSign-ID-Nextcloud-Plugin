<?php
script('secsignid','secsignid_settings');
?>

<div class="section" >
    <h2 style="padding-left: 12px">SecSign ID</h2>
    <p>To make sure you aren't locked out of your account, please head over to your personal security settings and make sure you have saved your 2FA backup codes and have assigned a SecSign ID to your account.</p>
    <button id="sec-goToSettings">Go to Settings</button>
   
</div>
