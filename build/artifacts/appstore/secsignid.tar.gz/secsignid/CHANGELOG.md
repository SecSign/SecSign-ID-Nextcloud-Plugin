## [Unreleased]
### Added
- Onboarding for users
- Choose a specific SecSign ID server to query

## 0.1.0 - 2019-02-26
### Added
- Simple integration of SecSign ID 2FA
- User management
